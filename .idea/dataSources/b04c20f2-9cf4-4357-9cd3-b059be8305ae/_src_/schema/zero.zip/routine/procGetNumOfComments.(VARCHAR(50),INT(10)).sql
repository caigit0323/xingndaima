CREATE PROCEDURE procGetNumOfComments(IN `_title` VARCHAR(50), IN numOfComments INT(10))
  begin 
		select count(*) into numOfComments from comment where blog_id=
		(select id from blog where title=_title);
end;
