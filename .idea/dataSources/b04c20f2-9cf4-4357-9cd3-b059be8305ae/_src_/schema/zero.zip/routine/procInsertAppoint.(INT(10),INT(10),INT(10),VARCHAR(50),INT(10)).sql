CREATE PROCEDURE procInsertAppoint(IN `_u_id`       INT(10), IN `_patient_id` INT(10), IN `_m_id` INT(10),
                                   IN `_visit_time` VARCHAR(50), IN available INT(10))
  begin 
		declare _visit_seq int default 0; -- 预约号
		declare _limit_visits int;  -- 预约数极限
		set available=1;
		-- 取得医生ID为_m_id的该位医生的最大预约数
		select limit_visits into _limit_visits from mediciner where mid=_m_id;
			-- 取得ID为_patient_id的病人所预约的ID为_m_id的医生的就诊时间为_visit_time的当前最
-- 大预约号
		select count(1) into _visit_seq from appointment 
		where m_id=_m_id and visit_time=_visit_time;
		-- 当前最大预约号小于预约数极限
		if(_visit_seq<_limit_visits) then
				set _visit_seq=_visit_seq+1; -- 预约号递增
				-- 新增预记录
				insert into appointment(u_id,patient_id,m_id,visit_time,visit_seq) 
				values(_u_id,_patient_id,_m_id,_visit_time,_visit_seq);
		else
				set available=0; -- 如果预约号达到极限则关闭预约开关
		end if;
end;
